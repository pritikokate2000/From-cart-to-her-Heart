 // Ensure the DOM is fully loaded
 document.getElementById('loginBtn').addEventListener('click', function() {
    alert('Button clicked!');
    window.location.href = 'D:/ITV/My Own Project/Her cart/login.html';
});